// BACKEND - Express.js

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(bodyParser.json());

let services = [
  { id: uuidv4(), name: 'Lavagem Simples', price: 'R$ 50,00', time: '1h' },
  { id: uuidv4(), name: 'Polimento', price: 'R$ 150,00', time: '2h' },
  { id: uuidv4(), name: 'Cristalização', price: 'R$ 200,00', time: '1.5h' }
];

// GET /services
app.get('/services', (req, res) => {
  res.json(services);
});

// POST /services
app.post('/services', (req, res) => {
  const newService = { id: uuidv4(), ...req.body };
  services.push(newService);
  res.status(201).json(newService);
});

// PUT /services/:id
app.put('/services/:id', (req, res) => {
  const { id } = req.params;
  const index = services.findIndex(s => s.id === id);
  if (index !== -1) {
    services[index] = { ...services[index], ...req.body };
    res.json(services[index]);
  } else {
    res.status(404).json({ error: 'Serviço não encontrado' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
